The data files in this directory were obtained from the public IANA time zone database,
http://www.iana.org/time-zones, version 2014j.
